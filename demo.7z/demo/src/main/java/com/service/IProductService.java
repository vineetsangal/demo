package com.service;

import java.util.List;

import com.model.Product;

public interface IProductService {
	List<Product> findAll(); 

}
